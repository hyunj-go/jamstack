'use strict';

/**
 * bakery router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bakery.bakery');
