'use strict';

/**
 * bakery controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bakery.bakery');
